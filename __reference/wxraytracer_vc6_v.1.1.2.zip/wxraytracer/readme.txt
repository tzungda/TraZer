vxRaytracer for Microsoft Visual C++ 6.0
----------------------------------------------

The project requires Visual Studio Service Pack 6 or later installed. This service pack can be
downloaded from the Microsoft website and is ~ 60MB to download.
